# Quick start

> An awesome project's another page.
