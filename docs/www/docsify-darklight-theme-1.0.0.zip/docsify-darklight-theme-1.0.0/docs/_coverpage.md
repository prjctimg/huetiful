<!-- ![logo](https://cdn.jsdelivr.net/npm/docsify-darklight-theme@latest/icons/docsify-darklight-theme-logo.png)

# docsify-darklight-theme-starter

> A magical documentation site generator with dark and light mode switch.

- Themes are customizable based on your color preferences.
- Themes are remembered and retrieved from local storage.
- Redesigned search box.

[Preview](https://boopathikumar018.github.io/docsify-darklight-theme)
[Getting Started](#docsify) -->
