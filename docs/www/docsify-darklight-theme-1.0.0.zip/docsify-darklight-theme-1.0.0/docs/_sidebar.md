- Getting started

  - [Installation](installation.md)
  - [Configuration](configuration.md)
  - [Theme Support](themeSupport.md)

- Others

  - [Changelog](changelog.md)