import { terser } from 'rollup-plugin-terser'

module.exports = {
  plugins: [terser()]
}
